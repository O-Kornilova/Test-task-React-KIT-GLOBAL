import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import type { Post } from "@/types";

// ─── Async Thunks ─────────────────────────────────────────────────────────────

export const fetchPostsThunk = createAsyncThunk("posts/fetchAll", async () => {
  const res = await fetch("/api/posts");
  if (!res.ok) throw new Error("Failed to fetch posts");
  return res.json() as Promise<Post[]>;
});

export const createPostThunk = createAsyncThunk(
  "posts/create",
  async (data: Omit<Post, "id" | "createdAt" | "updatedAt" | "commentCount">) => {
    const res = await fetch("/api/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to create post");
    return res.json() as Promise<Post>;
  }
);

export const updatePostThunk = createAsyncThunk(
  "posts/update",
  async ({ id, data }: { id: string; data: Partial<Post> }) => {
    const res = await fetch(`/api/posts/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to update post");
    return res.json() as Promise<Post>;
  }
);

export const deletePostThunk = createAsyncThunk(
  "posts/delete",
  async (id: string) => {
    const res = await fetch(`/api/posts/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to delete post");
    return id;
  }
);

// ─── Slice ────────────────────────────────────────────────────────────────────

interface PostsState {
  items: Post[];
  status: "idle" | "loading" | "succeeded" | "failed";
  error: string | null;
}

const initialState: PostsState = {
  items: [],
  status: "idle",
  error: null,
};

const postsSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {
    // Seed posts from SSR initial data
    setPosts(state, action: PayloadAction<Post[]>) {
      state.items = action.payload;
      state.status = "succeeded";
    },
  },
  extraReducers: (builder) => {
    builder
      // fetchAll
      .addCase(fetchPostsThunk.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchPostsThunk.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.items = action.payload;
      })
      .addCase(fetchPostsThunk.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message ?? "Unknown error";
      })
      // create
      .addCase(createPostThunk.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
      })
      // update
      .addCase(updatePostThunk.fulfilled, (state, action) => {
        const idx = state.items.findIndex((p) => p.id === action.payload.id);
        if (idx !== -1) state.items[idx] = action.payload;
      })
      // delete
      .addCase(deletePostThunk.fulfilled, (state, action) => {
        state.items = state.items.filter((p) => p.id !== action.payload);
      });
  },
});

export const { setPosts } = postsSlice.actions;
export default postsSlice.reducer;
